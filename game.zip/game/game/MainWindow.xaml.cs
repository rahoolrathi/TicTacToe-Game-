﻿using System;
using System.Windows;
using System.Windows.Threading;

namespace game
{

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
          
        }

        private void User_Click(object sender, RoutedEventArgs e)
        {

            this.Visibility = Visibility.Hidden;
            new UserToUserWindow().Show();
        }

        private void Computer_Click(object sender, RoutedEventArgs e)
        {
            DispatcherTimer dt = new DispatcherTimer();
            dt.Interval =TimeSpan.FromSeconds(0);
            this.Visibility = Visibility.Hidden;
            new UserToComputerWindow().Show();
        }
    }
}
