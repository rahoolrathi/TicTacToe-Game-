﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace game
{
    
    public partial class UserToUserWindow : Window
    {
        public UserToUserWindow()
        {
            InitializeComponent();
        }
        int count = 0;
        String checkwinner(String sysmbol)
        {

            if(button1.Content.ToString()==sysmbol &&  button2.Content.ToString() == sysmbol && button3.Content.ToString() == sysmbol)
            {
                return sysmbol;
            } 
            else if (button4.Content.ToString() == sysmbol && button5.Content.ToString() == sysmbol && button6.Content.ToString() == sysmbol)
            {
                return sysmbol;
            }
            else if (button7.Content.ToString() == sysmbol && button8.Content.ToString() == sysmbol && button9.Content.ToString() == sysmbol)
            {
                return sysmbol;
            }
            else if (button1.Content.ToString() == sysmbol && button4.Content.ToString() == sysmbol && button7.Content.ToString() == sysmbol)
            {
                return sysmbol;
            }
            else if (button2.Content.ToString() == sysmbol && button5.Content.ToString() == sysmbol && button8.Content.ToString() == sysmbol)
            {
                return sysmbol;
            }
            else if (button3.Content.ToString() == sysmbol && button6.Content.ToString() == sysmbol && button9.Content.ToString() == sysmbol)
            {
                return sysmbol;
            }
            else if (button1.Content.ToString() == sysmbol && button5.Content.ToString() == sysmbol && button9.Content.ToString() == sysmbol)
            {
                return sysmbol;
            }
            else if (button7.Content.ToString() == sysmbol && button5.Content.ToString() == sysmbol && button3.Content.ToString() == sysmbol)
            {
                return sysmbol;
            }
            return null;
 
    
        }
        void fnsymbol(object senderobj)
        {
            String check = null;
            String check1 = null;
            string btntxt = ((Button)senderobj).Content.ToString();
            if(btntxt=="")
            {
                if(count %2==0)
                {
                    ((Button)senderobj).Content = "O";
                }
                else
                {
                    ((Button)senderobj).Content = "X";
                }
                count++;
                check = checkwinner("O");
                check1=checkwinner("X");
                if(check!=null||check1!=null)
                {
                
                    String result;
                    if (check1 != null)
                        result = check1;
                    else
                        result = check;
                    this.Visibility = Visibility.Hidden;
                    new LastPage(result,true).Show();
                }
                else if(count==9&&check==null|| count == 9 && check1==null)
                {
              
                    this.Visibility = Visibility.Hidden;
                    new LastPage("",true).Show();
                }
            }
            else
            {
                MessageBox.Show("Invalid Click");
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            fnsymbol(sender);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            fnsymbol(sender);
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            fnsymbol(sender);
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            fnsymbol(sender);
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            fnsymbol(sender);
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            fnsymbol(sender);
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            fnsymbol(sender);
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            fnsymbol(sender);
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            fnsymbol(sender);
        }

       
    }
}
