﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace game
{
    
    public partial class UserToComputerWindow : Window
    {
        private int count = 0;
        private int won = -3;
        private Boolean check=false;
        private DispatcherTimer CPUTImer;
          public enum Player
        {
            X,O
        }
        Player currentPlayer;
        Random random = new Random();
        List<Button> buttons;
        public UserToComputerWindow()
        {
            InitializeComponent();
            RestartGame();

        }


        private void CPUMove(object sender, EventArgs e)
        {

          
            if (buttons.Count > 0)
            {
                int index = random.Next(buttons.Count);
                buttons[index].IsEnabled = false; 
                currentPlayer = Player.O; 
                buttons[index].Content = currentPlayer.ToString();              
                buttons.RemoveAt(index); 
                won=checkGame();
                if (won == 1)
                {
                    CPUTImer.Stop();
                    this.Visibility = Visibility.Hidden;
                    new LastPage("X", false).Show();
                }
                else if (won == 2)
                {
                    CPUTImer.Stop();
                    this.Visibility = Visibility.Hidden;
                    new LastPage("O", false).Show();
                }
                else if (won == 0)
                {
                    CPUTImer.Stop();
                    this.Visibility = Visibility.Hidden;
                    new LastPage("", false).Show();
                }
                else if (won == -1)
                    CPUTImer.Stop(); 
            }
        }

        

        private void Player_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            currentPlayer = Player.X;
             button.Content = currentPlayer.ToString();
             button.IsEnabled = false;
             buttons.Remove(button);
              won=checkGame();
            if(won==1)
            {
                CPUTImer.Stop();
                this.Visibility = Visibility.Hidden;
                new LastPage("X", false).Show();
            }
            else if(won==2)
            {
                CPUTImer.Stop();
                this.Visibility = Visibility.Hidden;
                new LastPage("O", false).Show();
            }
            else if(won==0)
            {
                CPUTImer.Stop();
                this.Visibility = Visibility.Hidden;
                new LastPage("", false).Show();
            }
            else if(won==-1)
             CPUTImer.Start();
           }
        private void RestartGame()
        {
            CPUTImer = new DispatcherTimer();
            CPUTImer.Interval = TimeSpan.FromMilliseconds(500);
            CPUTImer.Tick += CPUMove;
            buttons = new List<Button> { button11, button12, button13, button14, button15, button16, button17, button18, button19 };
            foreach(Button i in buttons) {
                i.IsEnabled = true;
                i.Content = "";
            }
        }
        private int checkGame()
        {
            count++;
            if (button11.Content.ToString() == "X" && button12.Content.ToString() == "X" && button13.Content.ToString() == "X"
               || button14.Content.ToString() == "X" && button15.Content.ToString() == "X" && button16.Content.ToString() == "X"
               || button17.Content.ToString() == "X" && button18.Content.ToString() == "X" && button19.Content.ToString() == "X"
               || button11.Content.ToString() == "X" && button14.Content.ToString() == "X" && button17.Content.ToString() == "X"
               || button12.Content.ToString() == "X" && button15.Content.ToString() == "X" && button18.Content.ToString() == "X"
               || button13.Content.ToString() == "X" && button16.Content.ToString() == "X" && button19.Content.ToString() == "X"
               || button11.Content.ToString() == "X" && button15.Content.ToString() == "X" && button19.Content.ToString() == "X"
               || button13.Content.ToString() == "X" && button15.Content.ToString() == "X" && button17.Content.ToString() == "X")
            {
              
              
                return 1;
               
            }
            else if (button11.Content.ToString() == "0" && button12.Content.ToString() == "0" && button13.Content.ToString() == "0"
               || button14.Content.ToString() == "0" && button15.Content.ToString() == "0" && button16.Content.ToString() == "0"
               || button17.Content.ToString() == "0" && button18.Content.ToString() == "0" && button19.Content.ToString() == "0"
               || button11.Content.ToString() == "0" && button14.Content.ToString() == "0" && button17.Content.ToString() == "0 "
               || button12.Content.ToString() == "0" && button15.Content.ToString() == "0" && button18.Content.ToString() == "0"
               || button13.Content.ToString() == "0" && button16.Content.ToString() == "0" && button19.Content.ToString() == "0"
               || button11.Content.ToString() == "0" && button15.Content.ToString() == "0" && button19.Content.ToString() == "0"
               || button13.Content.ToString() == "0" && button15.Content.ToString() == "0" && button17.Content.ToString() == "0")
            {
            
                return 2;   
            }
            else if(count==9)
            {
                return 0;
            }
           
            return -1;
        }


    }
}
