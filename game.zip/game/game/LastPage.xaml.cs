﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace game
{
   
    public partial class LastPage : Window
    {

        public LastPage(String result,Boolean Player)
        {
            InitializeComponent();
            if (result == "O" && Player)
                result = "Player 1 Won the game";
            else if (result == "X" && Player)
                result = "Player 2 won the game";
            else if (result == "O" && !Player)
                result = "Computer won the game";
            else if (result == "X" && !Player)
                result = "Player  Won the game";
            else
            {
                label.Foreground = Brushes.Red;
                result = "Game Drawn";
            }
            label.Content = result;

        }

        private void Restart_Click(object sender, RoutedEventArgs e)
        {
           
            Application.Current.Shutdown();
            System.Diagnostics.Process.Start(Application.ResourceAssembly.Location);
       
        }
    }
}
